# -*- Mode: python; coding: utf-8; tab-width: 8; indent-tabs-mode: t; -*-

libsecret_enabled = True

